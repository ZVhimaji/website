document.addEventListener('click', function() {
  document.querySelector('.clickformusic').classList.add('fade-out');
}, { once: true });